TITLE: kindlepdfviewer

CONTAINS: KUAL files for installation in /mnt/us/extensions/ 

REF: Main KUAL thread http://www.mobileread.com/forums/showthread.php?t=203326

UPSTREAM SOURCE: https://github.com/hwhw/kindlepdfviewer

SUPPORTS: 
DX Yes ( All Revisions )
K3 Yes ( All Revisions )
K4 Yes ( All Revisions )
Touch (check github and threads for support information)
PW (check github and threads for support information)

REQUIRES: KindlePDFviewer http://www.mobileread.com/forums/showthread.php?t=157047

ARCHIVAL LINK: http://www.mobileread.com/forums/showpost.php?p=2406316&postcount=5

ORIGINAL AUTHOR: Hawhill, See GIT for subsequent contributors listing

NOTES: Touchscreen support for the Touch and PW is in progress
check github and threads for support information
