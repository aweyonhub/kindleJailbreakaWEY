remember to edit menu.json and change hostname:port

		{"name": "VNC Connection", "priority": 1, "action": "/mnt/us/kindlevncviewer/kvncviewer.sh hostname:port"}

to your ACTUAL machines values ;)

Check the threads

KVNC http://www.mobileread.com/forums/showthread.php?t=150434
KUAL http://www.mobileread.com/forums/showthread.php?t=203326

for any updates.
